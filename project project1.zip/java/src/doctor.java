
public class doctor {
	public static void main(String[] args) {
		doctor d1 =new doctor();
		d1.name="Anurag";
		d1.age=51.2f;
		System.out.println(d1.name);
		System.out.println(d1.age);
	
	    d1.examinePatient();
	}

	

}
