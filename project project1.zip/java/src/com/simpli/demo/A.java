package com.simpli.demo;

public class A {
	private int ccNo=3281977576785;
	class PersonalSecretary{
		public void m1() {
			System.out.println(ccNo);
		}
	}

}
public class InnerClassDemo{
	public static void main(String[] args) {
		VIP vip1=new Vip();
		VIP PersonalSecretary psec1=vip1.new PersonalSecretary;
	}
}