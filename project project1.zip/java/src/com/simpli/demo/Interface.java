package com.simpli.demo;

public class Interface {
	public static void main(String[] args) {
		
	}

}
interface X{
	public void sayHi(String name) {
		public int getsalary
	}
	
}