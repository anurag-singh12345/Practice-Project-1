
import java.util.Scanner;
public class fact {
	public static void main(String[] args) {
		int n;
		int k=1;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Number ");
		n=s.nextInt();
		int i=1;
		while(i<n) 
		{
			k=k*i;
			i++;
		}
		System.out.println(k);
	
		
		
	}

}
