public class array {
	static void minimum(int a[]) {
		int value=a[0];
		for(int i=1;i<a.length;i++)
		if(value>a[i])
		value=a[i];
		System.out.println(value);
	}
	public static void main(String[] args) {
		int x[] ={55,4,9,2};
		minimum(x);
		
		
		
	}

}
